import React, { useState, useEffect } from 'react';

const sections = [
  { id: 'acceptance', title: '1. Acceptance of Terms' },
  { id: 'what-is-mingle', title: '2. What Mingle Is' },
  { id: 'account-info', title: '3. Account Information Collected' },
  { id: 'pi-payments', title: '4. Pi Payments' },
  { id: 'kyc', title: '5. KYC Requirements' },
  { id: 'no-refunds', title: '6. No Refunds' },
  { id: 'user-content', title: '7. User-Generated Content' },
  { id: 'marketplace', title: '8. Marketplace Conduct' },
  { id: 'suspension', title: '9. Account Suspension' },
  { id: 'disclaimer', title: '10. Disclaimer of Warranties' },
  { id: 'changes', title: '11. Changes to Terms' },
  { id: 'contact', title: '12. Contact Us' },
];

export default function App() {
  const [active, setActive] = useState('acceptance');
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handler = () => {
      for (const s of sections) {
        const el = document.getElementById(s.id);
        if (!el) continue;
        const rect = el.getBoundingClientRect();
        if (rect.top <= 120) setActive(s.id);
      }
    };
    window.addEventListener('scroll', handler, { passive: true });
    return () => window.removeEventListener('scroll', handler);
  }, []);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    setMenuOpen(false);
  };

  return (
    <div className="page">
      {/* Header */}
      <header className="header">
        <div className="header-inner">
          <div className="logo">
            <span className="logo-icon">◎</span>
            <span className="logo-text">Mingle</span>
          </div>
          <span className="header-subtitle">Terms of Use</span>
          <button className="menu-btn" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu">
            {menuOpen ? '✕' : '☰'}
          </button>
        </div>
        {menuOpen && (
          <nav className="mobile-nav">
            {sections.map(s => (
              <button key={s.id} className={`mobile-nav-link ${active === s.id ? 'active' : ''}`} onClick={() => scrollTo(s.id)}>
                {s.title}
              </button>
            ))}
          </nav>
        )}
      </header>

      <div className="layout">
        {/* Sidebar */}
        <aside className="sidebar">
          <p className="sidebar-label">Contents</p>
          <nav>
            {sections.map(s => (
              <button key={s.id} className={`nav-link ${active === s.id ? 'active' : ''}`} onClick={() => scrollTo(s.id)}>
                {s.title}
              </button>
            ))}
          </nav>
        </aside>

        {/* Main Content */}
        <main className="main">
          <div className="hero">
            <h1>Terms of Use</h1>
            <p className="effective">Effective Date: July 1, 2025</p>
            <p className="intro">
              Welcome to <strong>Mingle</strong> — a social and marketplace app built on the Pi Network. By accessing or using Mingle, you agree to be bound by these Terms of Use. Please read them carefully before using the app.
            </p>
          </div>

          <section id="acceptance" className="section">
            <h2>1. Acceptance of Terms</h2>
            <p>By creating an account or using Mingle in any way, you confirm that you have read, understood, and agree to these Terms of Use and our Privacy Policy. If you do not agree, you must not use Mingle.</p>
            <p>These Terms constitute a legally binding agreement between you and Mingle. We reserve the right to update these Terms at any time. Continued use of the app after changes are posted constitutes your acceptance of the revised Terms.</p>
          </section>

          <section id="what-is-mingle" className="section">
            <h2>2. What Mingle Is</h2>
            <p>Mingle is a social and marketplace application built on the Pi Network ecosystem. It allows users to:</p>
            <ul>
              <li>Connect and interact socially with other Pi Network users</li>
              <li>Buy and sell goods and services using Pi cryptocurrency</li>
              <li>Discover community members, listings, and events within the Pi ecosystem</li>
            </ul>
            <p>Mingle is not affiliated with, endorsed by, or operated by Pi Network Core Team, unless explicitly stated. We are an independent application built to run within the Pi ecosystem.</p>
          </section>

          <section id="account-info" className="section">
            <h2>3. Account Information Collected</h2>
            <p>To use Mingle, we collect only the minimum information required to provide our services:</p>
            <ul>
              <li><strong>Username</strong> — your display identity on the platform</li>
              <li><strong>Pi Wallet Address</strong> — used to facilitate Pi payments and transactions</li>
              <li><strong>Email Address</strong> — used for account login, notifications, and support</li>
            </ul>
            <p>We do not collect payment card information, government-issued IDs (beyond what KYC requires as described below), or sensitive personal data beyond the above. Your data is used solely to operate Mingle and will not be sold to third parties.</p>
          </section>

          <section id="pi-payments" className="section">
            <h2>4. Pi Payments</h2>
            <p>Mingle enables peer-to-peer Pi cryptocurrency payments between users for goods and services listed on the marketplace. By using the payment features you acknowledge and agree that:</p>
            <ul>
              <li>All Pi transactions are conducted directly between users via the Pi Network blockchain</li>
              <li>Mingle acts only as a platform facilitating these transactions — we are not a party to any transaction between buyers and sellers</li>
              <li>You are solely responsible for verifying the legitimacy of any listing, buyer, or seller before transacting</li>
              <li>Pi payments are final and irreversible once confirmed on the Pi Network blockchain</li>
              <li>Mingle is not responsible for any loss, fraud, or dispute arising from user-to-user transactions</li>
            </ul>
          </section>

          <section id="kyc" className="section">
            <h2>5. KYC Requirements</h2>
            <p>In order to send or receive Pi payments through Mingle, users must have completed Pi Network's Know Your Customer (KYC) verification process as required by the Pi Network.</p>
            <ul>
              <li>KYC is managed entirely by Pi Network — Mingle does not collect or store your KYC documents</li>
              <li>Users who have not completed KYC will be restricted from accessing payment features on Mingle</li>
              <li>Mingle reserves the right to require additional identity verification if required by applicable laws or regulations</li>
              <li>You agree not to attempt to circumvent or falsify any KYC process</li>
            </ul>
          </section>

          <section id="no-refunds" className="section">
            <h2>6. No Refunds</h2>
            <div className="callout">
              <strong>All Pi payments made through Mingle are final and non-refundable.</strong>
            </div>
            <p>Because Pi transactions are executed on a decentralised blockchain, they cannot be reversed by Mingle once confirmed. You understand and agree that:</p>
            <ul>
              <li>Mingle does not issue refunds for any Pi transferred between users</li>
              <li>Any disputes regarding goods or services must be resolved directly between the buyer and seller</li>
              <li>Mingle may, at its sole discretion, mediate disputes but is under no obligation to do so and cannot guarantee resolution</li>
              <li>You are strongly encouraged to verify listings, communicate with the other party, and exercise caution before making any payment</li>
            </ul>
          </section>

          <section id="user-content" className="section">
            <h2>7. User-Generated Content</h2>
            <p>Mingle allows users to post content including listings, messages, photos, reviews, and other material ("User Content"). By submitting User Content you agree that:</p>
            <ul>
              <li>You own or have the right to share the content you post</li>
              <li>You grant Mingle a non-exclusive, royalty-free licence to display and distribute your content within the app</li>
              <li>You will not post content that is illegal, defamatory, abusive, fraudulent, obscene, or in violation of any third-party rights</li>
              <li>You will not post misleading listings, fake reviews, or spam</li>
            </ul>
            <p>Mingle reserves the right to remove any User Content that violates these Terms at any time, without notice.</p>
          </section>

          <section id="marketplace" className="section">
            <h2>8. Marketplace Conduct</h2>
            <p>All users of the Mingle marketplace agree to the following conduct standards:</p>
            <ul>
              <li>You will only list items or services that are legal in your jurisdiction</li>
              <li>You will not list prohibited items including (but not limited to) weapons, illegal substances, counterfeit goods, or stolen property</li>
              <li>You will accurately describe all listings, including condition, price, and delivery terms</li>
              <li>You will communicate honestly and respectfully with other users</li>
              <li>You will not engage in price manipulation, bid rigging, or any fraudulent market activity</li>
            </ul>
            <p>Mingle reserves the right to remove listings and suspend accounts that violate these standards.</p>
          </section>

          <section id="suspension" className="section">
            <h2>9. Account Suspension</h2>
            <p>Mingle may suspend or permanently ban any account that:</p>
            <ul>
              <li>Violates any provision of these Terms of Use</li>
              <li>Engages in fraud, deception, harassment, or abuse of other users</li>
              <li>Attempts to manipulate or exploit the Pi payment system</li>
              <li>Fails KYC requirements or provides false identification information</li>
              <li>Receives repeated substantiated complaints from other users</li>
            </ul>
            <p>In cases of suspension, any pending or unresolved transactions may be cancelled. Mingle is not liable for any losses resulting from account suspension where the suspension is due to a violation of these Terms.</p>
          </section>

          <section id="disclaimer" className="section">
            <h2>10. Disclaimer of Warranties</h2>
            <p>Mingle is provided on an <strong>"as is"</strong> and <strong>"as available"</strong> basis without any warranties of any kind, whether express or implied. We do not warrant that:</p>
            <ul>
              <li>The app will be uninterrupted, error-free, or free of viruses or harmful components</li>
              <li>Any transactions conducted through the app will be completed successfully</li>
              <li>The Pi Network blockchain will function as expected at any given time</li>
            </ul>
            <p>To the fullest extent permitted by law, Mingle disclaims all liability for any indirect, incidental, or consequential damages arising from your use of the app.</p>
          </section>

          <section id="changes" className="section">
            <h2>11. Changes to Terms</h2>
            <p>We may modify these Terms of Use at any time. When we make material changes, we will notify you by:</p>
            <ul>
              <li>Posting a notice within the Mingle app</li>
              <li>Sending an email to the address associated with your account</li>
              <li>Updating the "Effective Date" at the top of this page</li>
            </ul>
            <p>Your continued use of Mingle after any changes take effect constitutes your acceptance of the new Terms. If you do not agree to the new Terms, you must stop using the app.</p>
          </section>

          <section id="contact" className="section">
            <h2>12. Contact Us</h2>
            <p>If you have any questions, concerns, or feedback regarding these Terms of Use or the Mingle app, please reach out to us:</p>
            <div className="contact-card">
              <div className="contact-icon">✉</div>
              <div>
                <p className="contact-label">Email</p>
                <a href="mailto:mingle.app.pi@gmail.com" className="contact-email">mingle.app.pi@gmail.com</a>
              </div>
            </div>
            <p>We aim to respond to all enquiries within 5 business days.</p>
          </section>

          <footer className="footer">
            <p>© {new Date().getFullYear()} Mingle. All rights reserved.</p>
            <p>Built on the Pi Network ecosystem.</p>
          </footer>
        </main>
      </div>
    </div>
  );
}
